
/** /brief Función utilizada para ejecutar la suma entre dos números reales
*
* \param float (recibe un número real)
* \param float (recibe un numero real)
* \return float (retorna un número real, la suma)
*
*/
float suma (float,float);


/** /brief Función utilizada para ejecutar la resta entre dos números reales
*
* \param float (recibe un número real, que utilizará como minuendo)
* \param float (recibe un numero real, que utilizará como sustraendo)
* \return float (retorna un número real, la diferencia)
*
*/
float resta (float,float);


/** /brief Función utilizada para ejecutar la división de dos números reales
*
* \param float (recibe un número real, que utilizará como dividendo)
* \param float (recibe un numero real, que utilizará como divisor)
* \return float (retorna un numero real, el cociente)
*
*/
float division ( float,float);


/** /brief Función utilizada para ejecutar la multiplicación entre dos números reales
*
* \param float (recibe un número real)
* \param float (recibe un numero real)
* \return float (retorna un número real, el producto)
*
*/
float multiplicacion (float,float);


/** /brief Función utilizada para calcular el factorial de un número natural menor o igual a doce
*
* \param int (recibe un número natural)
* \return int (retorna un número natural, el factorial de ese número)
*
*/
int factorial (int);
