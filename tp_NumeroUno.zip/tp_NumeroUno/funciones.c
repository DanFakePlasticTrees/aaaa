#include "funciones.h"

float suma ( float a, float b){
float resultado;
resultado = a+b;
return resultado;
}

float resta (float a, float b){
 float resultado;
resultado = a-b;
return resultado;
}

float multiplicacion (float a, float b){
float resultado;
resultado = a*b;
return resultado;
}

float division (float a, float b){
float resultado;
resultado = a/b;
return resultado;
}

int factorial( int numero){
if(numero==1||numero==0)
{
numero=1;
} else {
numero=numero*factorial(numero-1);
}
return numero;
}
