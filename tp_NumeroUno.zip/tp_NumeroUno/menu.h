/** /brief Función que opera como menu de la calculadora
*
* \param void
* \return void
*
*/

void menuOpciones(void);
